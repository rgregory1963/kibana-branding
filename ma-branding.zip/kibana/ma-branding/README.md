# Kibana plugin for MA  styles
