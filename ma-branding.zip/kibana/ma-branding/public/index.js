import 'plugins/ma-branding/less/main.less';

addBanner = function() {
  var header= $(".header-global-wrapper");
  header.prepend("This is the banner");
  
}

addBanner();

